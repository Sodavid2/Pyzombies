from library import *
from commands import *
a = r.choices(abandoned_house.loot, abandoned_house.loot_weight, k=30)
for i in a:
    print(i.name)